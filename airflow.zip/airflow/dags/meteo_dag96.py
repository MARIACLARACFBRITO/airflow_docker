from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
import pendulum
import pandas as pd
import requests
from requests.auth import HTTPBasicAuth
from io import StringIO
from os.path import join, exists
import os

username = 'fiap_brito_maria'
password = 'RSjx0r2W61'

# Lista de localizações (latitude e longitude) com os principais bairros de São Paulo
locations = [
    {"nome": "AguaRasa", "latitude": "-23.5586", "longitude": "-46.5636"},
    {"nome": "AltodePinheiros", "latitude": "-23.5715", "longitude": "-46.7017"},
    {"nome": "Anhanguera", "latitude": "-23.4133", "longitude": "-46.7524"},
    {"nome": "Aricanduva", "latitude": "-23.5721", "longitude": "-46.5171"},
    {"nome": "ArturAlvim", "latitude": "-23.5374", "longitude": "-46.5024"},
    {"nome": "BelaVista", "latitude": "-23.5594", "longitude": "-46.6456"},
    {"nome": "Belem", "latitude": "-23.5314", "longitude": "-46.5919"},
    {"nome": "BomRetiro", "latitude": "-23.5291", "longitude": "-46.6345"},
    {"nome": "Bras", "latitude": "-23.5418", "longitude": "-46.6166"},
    {"nome": "Brasilandia", "latitude": "-23.4643", "longitude": "-46.6798"},
    {"nome": "Butanta", "latitude": "-23.5749", "longitude": "-46.7150"},
    {"nome": "Cachoeirinha", "latitude": "-23.4781", "longitude": "-46.6610"},
    {"nome": "Cambuci", "latitude": "-23.5673", "longitude": "-46.6243"}
]

# Lista de parâmetros meteorológicos
parametros = 'wind_speed_10m:ms,wind_dir_10m:d,wind_gusts_10m_1h:ms,t_2m:C,t_max_2m_24h:C,msl_pressure:hPa,precip_1h:mm,precip_24h:mm'

# Função para extrair dados
def extract_data(execution_date, latitude, longitude, location_name):
    start_date = pendulum.parse(execution_date)
    end_date = start_date.add(days=10)
    start_date_str = start_date.to_iso8601_string()
    end_date_str = end_date.to_iso8601_string()

    # Construir a URL com os parâmetros meteorológicos
    url = f'https://api.meteomatics.com/{start_date_str}--{end_date_str}:PT1H/{parametros}/{latitude},{longitude}/csv'
    
    print(f"Requesting data from URL: {url}")  # Debug: Imprimir URL para verificar
    response = requests.get(url, auth=HTTPBasicAuth(username, password))
    
    if response.status_code != 200:
        print(f"Failed to retrieve data: {response.text}")
        response.raise_for_status()

    data = pd.read_csv(StringIO(response.text))
    
    base_path = f'D:\\challenge\\meteomatics_data\\docker_teste\\{location_name}'  # Atualizado para o caminho no container
    if not exists(base_path):
        os.makedirs(base_path)
    
    file_path = join(base_path, f'data_{location_name}_{start_date.strftime("%Y-%m-%d")}_to_{end_date.strftime("%Y-%m-%d")}.csv')
    data.to_csv(file_path, index=False)
    print(f"Data saved to {file_path}")

# Definindo o DAG
with DAG(
        "meteo_bairro96_sp",
        start_date=pendulum.datetime(2024, 10, 5, tz='UTC'),
        schedule_interval='0 0 * * 1',
) as dag:
    # Tarefa de início
    start_task = DummyOperator(task_id='start')

    # Tarefas de extração de dados
    for location in locations:
        task = PythonOperator(
            task_id=f'extract_data_{location["nome"]}',
            python_callable=extract_data,
            op_kwargs={
                'execution_date': '{{ ds }}',
                'latitude': location['latitude'],
                'longitude': location['longitude'],
                'location_name': location['nome']
            }
        )
        start_task >> task
